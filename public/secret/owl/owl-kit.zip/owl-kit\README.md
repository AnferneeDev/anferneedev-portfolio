$kit = "C:\owl-kit"
$dir = "$env:LOCALAPPDATA\Programs\tailcat"
$cfg = "$env:USERPROFILE\.tailcat-owl"
New-Item -ItemType Directory -Force $dir, $cfg | Out-Null
Copy-Item "$kit\tailcat.exe" $dir -Force
Copy-Item "$kit\authorized_keys" $cfg -Force
& "$dir\tailcat.exe" genkey --key=default
& "$dir\tailcat.exe" serve --allow=nodekey:fdea5d979dc6043c552faf8f13180c21dd4679b01d6d36d21fa3d9ef566c5d6e,nodekey:d52fe18607dae1580e219491fb1f25267e072fe4718b8cb7c855eab797dcbd6d --ssh-authorized-keys="$cfg\authorized_keys" ssh
